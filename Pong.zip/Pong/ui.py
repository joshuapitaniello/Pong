from turtle import Turtle


class UI(Turtle):

    def __init__(self, text=""):
        super().__init__()
        if text == "":
            self.create_line()
        else:
            self.create_text(text)
        pass

    def create_line(self):
        self.hideturtle()
        self.color("azure3")  # White is more visible against the black background
        self.penup()
        self.goto(0, -300)  # Start at the bottom half of the desired length
        self.pensize(5)
        self.shape("square")
        self.setheading(90)
        for i in range(21):
            self.pendown()
            self.forward(10)
            self.penup()
            self.forward(20)

    def create_text(self, text):
        self.penup()
        self.score = 0
        self.hideturtle()
        self.color("white")

        if text == "right":
            self.goto(50, 220)
            self.write(f"{self.score}", align="center", font=("Arial", 50, "bold"))

        elif text == "left":
            self.goto(-50, 220)
            self.write(f"{self.score}", align="center", font=("Arial", 50, "bold"))

        else:
            print("Please input left or right")

    def display_text(self):
        self.clear()
        self.write(f"{self.score}", align="center", font=("Arial", 50, "bold"))
