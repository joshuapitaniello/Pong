import random
from turtle import Turtle


class Ball(Turtle):

    def __init__(self):
        super().__init__()
        self.create_ball()

    def create_ball(self):
        self.penup()
        self.shape("circle")
        self.color("white")
        self.shapesize(1)
        self.move_speed = 0.5
        self.move_x = 3
        self.move_y = 3

    def reset_ball(self):
        self.penup()
        self.goto(0, 0)
        self.penup()
        starting_choices = [3, -3]
        self.move_x = random.choice(starting_choices)
        self.move_y = random.choice(starting_choices)

    def move(self):
        new_x = self.xcor() + self.move_x
        new_y = self.ycor() + self.move_y
        self.goto(new_x, new_y)

    def bounce(self):
        # Top or Bottom bounce
        if self.ycor() > 280 or self.ycor() < -280:
            self.move_y *= -1
        else:
            self.move_x *= -1
    def increase_speed(self):
        self.move_x += self.move_speed
        self.move_y += self.move_speed




