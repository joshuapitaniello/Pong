from turtle import Turtle


class Paddle(Turtle):

    # constructor
    def __init__(self, x , y):
        super().__init__()
        self.create_square(x, y)

    def create_square(self, x, y):
        self.penup()
        self.shape("square")
        self.shapesize(stretch_wid=8, stretch_len=1)
        self.color("white")
        self.goto(x, y)


    def go_up(self):
        if self.ycor() > 200:
            return
        new_y = self.ycor() + 20
        self.goto(self.xcor(), new_y)

    def go_down(self):
        if self.ycor() < -200:
            return
        new_y = self.ycor() - 20
        self.goto(self.xcor(), new_y)