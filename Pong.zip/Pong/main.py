from turtle import Screen
import time

# Custom Classes imports
from paddle import Paddle
from ball import Ball
from ui import UI

# Screen Setup
screen = Screen()
screen.bgcolor("black")
screen.title("Py_Pong")
screen.setup(width=800, height=600)
screen.tracer(0) # get rid of inital animation

# game variables
game_is_on = True

# Paddle creation
r_paddle = Paddle(350, 0)
l_paddle = Paddle(-350, 0)

# Ball creation
ball = Ball()

# UI creation
dashed_line = UI()
right_paddle_score = UI("right")
left_paddle_score = UI("left")

# game keystrokes
screen.listen()

screen.onkeypress(r_paddle.go_up, "Up")
screen.onkeypress(r_paddle.go_down, "Down")

screen.onkeypress(l_paddle.go_up, "w")
screen.onkeypress(l_paddle.go_down, "s")


def handle_ball_trail():
    # This function will clear the ball's trail after every 10 moves
    if hasattr(handle_ball_trail, "counter"):
        if handle_ball_trail.counter >= 10:  # Clear the trail after 10 moves
            ball.clear()
            ball.penup()  # Lift the pen to move without drawing
            ball.goto(ball.xcor(), ball.ycor())  # Move to the ball's current position
            ball.pendown()  # Put the pen back down to draw
            handle_ball_trail.counter = 0  # Reset the counter
        else:
            handle_ball_trail.counter += 1  # Increment the counter each move
    else:
        handle_ball_trail.counter = 0  # Initialize the counter on the first call


while game_is_on:
    screen.update()

    # detect collision with top or bottom of bounds
    if ball.ycor() > 300 or ball.ycor() < -300:
        ball.bounce()

    # detect collision with right paddle
    if ball.distance(r_paddle) < 50 and ball.xcor() > 340:
        ball.bounce()

    # detect collision with left paddle
    if ball.distance(l_paddle) < 50 and ball.xcor() < -340:
        ball.bounce()

    # right paddle score
    if ball.xcor() > 500:
        left_paddle_score.score += 1
        left_paddle_score.display_text()
        ball.increase_speed()
        ball.reset_ball()

    # left paddle score
    if ball.xcor() < -500:
        right_paddle_score.score += 1
        right_paddle_score.display_text()
        ball.increase_speed()
        ball.reset_ball()

    handle_ball_trail()
    ball.move()
    time.sleep(0.01)

# Keep screen up until click
screen.exitonclick()


